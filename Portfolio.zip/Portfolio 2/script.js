var typed = new Typed(".typing", {
    strings: ["Web Designer"],
    typeSpeed: 50, 
    backSpeed: 40, 
    loop: true
});


document.getElementById('contactForm').addEventListener('submit', function(event) {
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const message = document.getElementById('message').value.trim();
    const errorMsg = document.getElementById('error-msg');
    const successMsg = document.getElementById('success-msg');
    
    // Reset messages
    errorMsg.textContent = '';
    successMsg.textContent = '';
    
    // Validate name
    if (!name) {
      errorMsg.textContent = 'Name is missing.';
      event.preventDefault();
      return;
    }
    
    // Validate email
    if (!validateEmail(email)) {
      errorMsg.textContent = 'Invalid email address.';
      event.preventDefault();
      return;
    }
    
    // Validate message
    if (!message) {
      errorMsg.textContent = 'Message is missing.';
      event.preventDefault();
      return;
    }
    
    // If all fields are valid
    successMsg.textContent = 'Message successfully sent!';
    event.preventDefault(); // Prevents form from submitting (remove this if you want the form to submit)
    
    // Clear the form fields after successful submission
    document.getElementById('contactForm').reset();
  });
  
  // Email validation function
  function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(String(email).toLowerCase());
  }
  
  // Get the current URL of the page
const currentPage = window.location.pathname;

// Remove any existing 'active' class first
document.querySelectorAll('nav ul li a').forEach(link => {
  link.classList.remove('active');
});

